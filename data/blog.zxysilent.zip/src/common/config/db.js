
"use strict";

exports.__esModule = true;
exports.default = {
    "type": "mysql",
    "adapter": {
        "mysql": {
            "host": "127.0.0.1",
            "port": "3306",
			"encoding": "utf8mb4",
            "database": "zblog",
            "user": "cwnujwc2013",
            "password": "Cf9erAdCHe6xFD7Z",
            "prefix": "z_",
            "type": "mysql"
        }
    }
};